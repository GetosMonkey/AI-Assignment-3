# Setup Instructions: 

Basically once you download the notebook that's all you need, other than to have the dataset as folder in the same folder/directory as the notebook so that my program can correctly read it in.

Assignment3.ipynb: Main program where all my working code blocks are
.gitignore: File mainly for version control on my github
README.md: setup instructions

(the report will be submitted as a seperate pdf)

The file structure should look something like this: 

Mode                 LastWriteTime         Length Name
----                 -------------         ------ ----
d-----         10/1/2025  10:21 AM                .ipynb_checkpoints
d-----         10/1/2025  10:12 AM                A3-dataset
-a----         8/25/2025   9:05 PM            283 .gitignore
-a----         10/4/2025  12:22 PM         375531 AI Assignment 3.pdf
-a----         10/3/2025  11:05 PM         272670 Assignment3.ipynb
-a----         9/16/2025   8:15 AM            989 README.md